<?php
class Bmi_pasien_model extends CI_Model {
    public $id;
    public $tanggal;
    public $pasien;
    public $bmi;
}