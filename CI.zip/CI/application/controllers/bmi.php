    <?php
defined('BASEPATH') OR exit('No direct script access allowe
d');
class BMI extends CI_Controller {

    public function index() {
        $this->load->model('pasien_model','pasien1');
        $this->pasien1->id=1;
        $this->pasien1->kode='010001';
        $this->pasien1->nama='Faiz Fikri';
        $this->pasien1->tmp_lahir='Jakarta';
        $this->pasien1->tgl_lahir='1 Januari 2002';
        $this->pasien1->gender='L';
        
        $this->load->model('pasien_model','pasien2');
        $this->pasien2->id=2;
        $this->pasien2->kode='020001';
        $this->pasien2->nama='Pandan Wangi';
        $this->pasien2->tmp_lahir='Bogor';
        $this->pasien2->tgl_lahir='1 Februari 2002';
        $this->pasien2->gender='P';

        $this->load->model('pasien_model','pasien3');
        $this->pasien3->id=3;
        $this->pasien3->kode='030001';
    	$this->pasien3->nama='Kusnadi';     
        $this->pasien3->tmp_lahir='Solo';
        $this->pasien3->tgl_lahir='27 Agustus 1968';
        $this->pasien3->gender='L';


        $this->load->model('bmi_model', 'bmi1');
        $this->bmi1->berat=50;
        $this->bmi1->tinggi=169;
        
        $this->load->model('bmi_model', 'bmi2');
        $this->bmi2->berat=52;	
        $this->bmi2->tinggi=162;
        
        
        $this->load->model('bmi_model', 'bmi3');
        $this->bmi3->berat=46;
        $this->bmi3->tinggi=174;
       

        $this->load->model('bmi_pasien_model', 'bmipasien1');
        $this->bmipasien1->id=1;
        $this->bmipasien1->tanggal='2021-05-9';
        $this->bmipasien1->pasien='Faiz Fikri';
        $this->bmi1->nilaiBMI(); 
        $this->bmi1->statusBMI();

        $this->load->model('bmi_pasien_model', 'bmipasien2');
        $this->bmipasien2->id=2;
        $this->bmipasien2->tanggal='2021-05-10';
        $this->bmipasien2->pasien='Pandan Wangi';
        $this->bmi2->nilaiBMI(); 
        $this->bmi2->statusBMI();

        $this->load->model('bmi_pasien_model', 'bmipasien3');
        $this->bmipasien3->id=3;
        $this->bmipasien3->tanggal='2021-05-11';
        $this->bmipasien3->pasien='Kusnadi';
        $this->bmi3->nilaiBMI(); 
        $this->bmi3->statusBMI();


        
        $list_pasien = [$this->pasien1, $this->pasien2, $this->pasien3];
        $list_bmipasien = [$this->bmipasien1, $this->bmipasien2, $this->bmipasien3];
        $list_bmi = [$this->bmi1, $this->bmi2, $this->bmi3];
        
        $data['list_pasien']=$list_pasien;
        $data['list_bmipasien']=$list_bmipasien;
        $data['list_bmi']=$list_bmi;
        
        $this->load->view('layout/header');
        $this->load->view('bmi/index', $data);
        $this->load->view('layout/footer');
    }
}
?>