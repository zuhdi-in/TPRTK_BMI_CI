<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>BMI</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />

        <link href="<?php echo base_url('asset/vendor/bootstrap/css/bootstrap.min.css') ?>" rel="stylesheet" >

        <link href="<?php echo base_url('asset/css/simple-sidebar.css') ?>" rel="stylesheet">
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body>
        <div class="d-flex" id="wrapper">
            <!-- Sidebar-->
            <div class="bg-light border-right" id="sidebar-wrapper">
                <div class="sidebar-heading">BMI</div>
                <div class="list-group list-group-flush">
                    <a class="list-group-item list-group-item-action bg-light" href="#!">Dashboard</a>
                    <a class="list-group-item list-group-item-action bg-light" href="http://localhost/CI/index.php/pasien">Detail Pasien</a>
                    <a class="list-group-item list-group-item-action bg-light" href="http://localhost/CI/index.php/bmi">BMI Pasien</a>
                    <a class="list-group-item list-group-item-action bg-light" href="#!">Events</a>
                    <a class="list-group-item list-group-item-action bg-light" href="#!">Profile</a>
                    <a class="list-group-item list-group-item-action bg-light" href="#!">Status</a>
                </div>
            </div>